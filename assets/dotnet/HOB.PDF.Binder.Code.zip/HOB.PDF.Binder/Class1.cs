﻿using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Runtime;
using System.Collections.Generic;
using Xfinium.Pdf;
using System.IO;

[assembly: ExtensionApplication(typeof(HOB.PDF.Binder.HOB_ini))]
[assembly: CommandClass(typeof(HOB.PDF.Binder.HOB_functions))]

namespace HOB.PDF.Binder
{
    //Initialization
    public class HOB_ini : IExtensionApplication
    {
        public void Initialize() { }
        public void Terminate() { }
    }

    //(hob-pdf-binder "C:\\temp\\4.pdf" (list "C:\\temp\\1.pdf" "C:\\temp\\2.pdf" "C:\\temp\\3.pdf"))
    public static class HOB_functions
    {
        [LispFunction("HOB-PDF-Binder")]
        public static bool HOB_PDF_Binder(ResultBuffer args)
        {
            List<string> pdfs = new List<string>();
            string binder = "";
            bool ret = true;
            if (args != null)
            {
                foreach (TypedValue tv in args.AsArray())
                {
                    if (tv.TypeCode == (int)LispDataType.Text)
                    {
                        if (binder == "")
                        { binder = (string)tv.Value; }
                        else
                        { pdfs.Add((string)tv.Value); }
                    }
                }
            }
            if (binder != "" && binder.ToUpper().EndsWith(".PDF") == true && Directory.Exists(Path.GetDirectoryName(binder)) == true)
            {                
                if (File.Exists(binder) == true)
                {
                    if (HOB_Helpers.IsFileLocked(new FileInfo(binder)) == false)
                    { File.Delete(binder); }
                    else
                    { return false; }
                }                
                PdfFixedDocument pdf = new PdfFixedDocument();
                foreach (string path in pdfs)
                {
                    if (File.Exists(path) == true && path.ToUpper().EndsWith(".PDF") == true)
                    { pdf.AppendFile(path); }
                    else
                    { ret = false; }
                }
                if (ret == false)
                {
                    Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor.WriteMessage("Some of the provided files could not be appended into: " + Path.GetFileName(binder));
                }
                pdf.Save(binder);
                return ret;
            }
            else
            { return false; }            
        }
    }

    public static class HOB_Helpers
    {
        public static bool IsFileLocked(FileInfo file)
        {
            FileStream stream = null;
            try
            {
                stream = file.Open(FileMode.Open, FileAccess.Read, FileShare.None);
            }
            catch (IOException)
            { return true; }
            finally
            {
                if (stream != null)
                    stream.Close();
            }            
            return false;
        }
    }
    
}
