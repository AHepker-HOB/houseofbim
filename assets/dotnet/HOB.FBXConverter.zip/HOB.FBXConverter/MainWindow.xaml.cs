﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HOB.FBXConverter
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            if (System.IO.File.Exists("C:\\Program Files\\Autodesk\\3ds Max 2019\\3dsmaxbatch.exe") == false)
            {
                MessageBox.Show("Could not locate 2019 3DS Max, this program is required to make this converter function", "Error");
                this.Close();
            }
        }

        private void btnConvert_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.Filter = "FBX File (*.fbx)|*.fbx";
            Dictionary<string, System.Diagnostics.Process> procs = new Dictionary<string, System.Diagnostics.Process>();
            dlg.RestoreDirectory = true;            
            dlg.Multiselect = true;
            if (dlg.ShowDialog() == true)
            {
                foreach (string file in dlg.FileNames)
                {
                    string fbase = file.Substring(0, file.Length - 4);
                    if (System.IO.File.Exists(fbase + ".dwg") == true) { System.IO.File.Delete(fbase + ".dwg"); }
                    if (System.IO.File.Exists(fbase + ".ms") == true) { System.IO.File.Delete(fbase + ".ms"); }
                    List<string> lines = new List<string>();
                    lines.Add("pluginManager.loadClass FbxImporter");
                    lines.Add("FBXImporterSetParam \"ConvertUnit\" \"" + (cmbUnit.SelectedItem as ComboBoxItem).Tag + "\"");
                    lines.Add("ImportFile \"" + file + "\" #noPrompt");
                    lines.Add("select $*");
                    lines.Add("group selection name:\"MyGroup\" select: true");                    
                    lines.Add("$MyGroup.pivot = [0, 0, 0]");
                    if (radX.IsChecked == true)
                    { lines.Add("rotate $MyGroup(angleaxis " + tbxRotation.Text.Trim() + "[1, 0, 0])"); }
                    else if (radY.IsChecked == true)
                    { lines.Add("rotate $MyGroup(angleaxis " + tbxRotation.Text.Trim() + "[0, 1, 0])"); }
                    else
                    { lines.Add("rotate $MyGroup(angleaxis " + tbxRotation.Text.Trim() + "[0, 0, 1])"); }
                    lines.Add("ungroup $MyGroup");
                    lines.Add("ExportFile \"" + fbase + ".dwg\" #noPrompt");
                    lines.Add("quitMAX quiet:true");
                    //lines.Add("quitMAX quiet:true exitCode: -314159");
                    System.IO.File.WriteAllLines(fbase + ".ms", lines);
                    procs.Add(fbase + ".ms", System.Diagnostics.Process.Start("C:\\Program Files\\Autodesk\\3ds Max 2019\\3dsmaxbatch.exe", fbase + ".ms"));
                }
                while (procs.Values.All(p => p.HasExited == false))
                { System.Threading.Thread.Sleep(500); }
                foreach (string file in procs.Keys)
                { System.IO.File.Delete(file); }
            }
        }

        private void Hyperlink_RequestNavigate(object sender, RequestNavigateEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.houseofbim.com");
        }
    }
}
