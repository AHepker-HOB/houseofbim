﻿
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.ProcessPower.PlantInstance;
using Autodesk.ProcessPower.PnP3dObjects;
using Autodesk.ProcessPower.P3dProjectParts;
using Autodesk.ProcessPower.DataLinks;
using Autodesk.ProcessPower.DataObjects;
using System.Collections.Generic;
using System.Collections.Specialized;

[assembly: ExtensionApplication(typeof(P3Dplugin.HOB_ini))]
[assembly: CommandClass(typeof(P3Dplugin.HOB_Functions))]

namespace P3Dplugin
{

    //Initialization
    public class HOB_ini : IExtensionApplication
    {
        public void Initialize()
        {
            Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor.WriteMessage
                (
                    "\nHouseOfBIM.com P3Dplugin was Loaded! You can now use GetPlantValues or SetPlantValues lisp functions\n" +
                    "(GetPlantValues EName PropNameList) to get specific values or (GetPlantValues EName \"*\") for all propertys\n" +
                    "SetPlantValues operates solely on the string properties of a P3D object and not all string properties are support writing.\n" +
                    "--Note: You can use GetPlantValues with an \"*\" to get a list of property names or visit houseofbim.com\n" +
                    "(SetPlantValues EName PropName NewValueString) Attempts to set your \"string\" value to a provided Property target.\n"                    
                );
        }
        public void Terminate() { }
    } // End HOB_ini





    // Function Definitions
    public class HOB_Functions
    {                
        [LispFunction("GetPlantValues")]
        public static ResultBuffer GetP3DValues(ResultBuffer args)
        {
            ResultBuffer result = new ResultBuffer();
            TypedValue[] tvList;
            ObjectId EntID = ObjectId.Null;
            List<string> PropNames = new List<string>();            
            try
            {
                tvList = args.AsArray();
                foreach (TypedValue tv in tvList)
                {
                    if (tv.TypeCode == (int)LispDataType.Text)
                    {
                        PropNames.Add(tv.Value.ToString().ToUpper().Trim());
                    }
                    if (tv.TypeCode == (int)LispDataType.ObjectId)
                    {
                        EntID = (ObjectId)tv.Value;
                    }
                }

            }
            catch
            {
                result.Add(new TypedValue((int)LispDataType.Nil));
                return result;
            }            
            if (EntID.IsNull == true || PropNames.Count < 1)
            {
                result.Add(new TypedValue((int)LispDataType.Nil));
                return result;
            }
            Autodesk.AutoCAD.ApplicationServices.Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor.Document;            
            PipingProject pipe = (PipingProject)PlantApplication.CurrentProject.ProjectParts["Piping"];
            DataLinksManager dlm = pipe.DataLinksManager;
            TransactionManager tm = doc.Database.TransactionManager;
            PnPDatabase pnpdb = dlm.GetPnPDatabase();
            int PnpRowIndex;
            List<KeyValuePair<string, string>> properties;
            result.Add(new TypedValue((int)LispDataType.ListBegin));
            using (Transaction tr = tm.StartTransaction())
            {
                try
                {
                    Part pPart = (Part)tr.GetObject(EntID, OpenMode.ForRead);
                    PnpRowIndex = dlm.FindAcPpRowId(EntID);
                    PnPRow row = pnpdb.GetRow(PnpRowIndex);
                    properties = dlm.GetAllProperties(PnpRowIndex, true);                    
                    foreach (KeyValuePair<string, string> x in properties)
                    {
                        if (PropNames.Contains(x.Key.ToUpper().Trim()) == true || PropNames.Contains("*") == true)
                        {
                            result.Add(new TypedValue((int)LispDataType.ListBegin));
                            result.Add(new TypedValue((int)LispDataType.Text, x.Key.ToUpper().Trim()));
                            result.Add(new TypedValue((int)LispDataType.Text, x.Value));
                            result.Add(new TypedValue((int)LispDataType.ListEnd));
                        }
                    }
                    #region "PORT Processing"
                    if (PropNames.Contains("PORTS") == true || PropNames.Contains("*") == true)
                    {
                        Autodesk.ProcessPower.PnP3dObjects.PortCollection pc = pPart.GetPorts(PortType.All);
                        result.Add(new TypedValue((int)LispDataType.ListBegin));// Create PORTS ASSOC group
                        result.Add(new TypedValue((int)LispDataType.Text, "PORTS"));
                        foreach (Port con in pc)
                        {
                            result.Add(new TypedValue((int)LispDataType.ListBegin));// Start Connector Index
                            //Use Connector name as ASSOC value
                            result.Add(new TypedValue((int)LispDataType.Text, con.Name));
                            result.Add(new TypedValue((int)LispDataType.ListBegin));// Start Wrap Values
                            //add the XYZ and Vector direction of this con Index
                            result.Add(new TypedValue((int)LispDataType.ListBegin));// Start Point List
                            result.Add(new TypedValue((int)LispDataType.Double, con.Position.X));
                            result.Add(new TypedValue((int)LispDataType.Double, con.Position.Y));
                            result.Add(new TypedValue((int)LispDataType.Double, con.Position.Z));
                            result.Add(new TypedValue((int)LispDataType.ListEnd));// End Point List
                            result.Add(new TypedValue((int)LispDataType.ListBegin));// Start Vector List
                            result.Add(new TypedValue((int)LispDataType.Double, con.Direction.X));
                            result.Add(new TypedValue((int)LispDataType.Double, con.Direction.Y));
                            result.Add(new TypedValue((int)LispDataType.Double, con.Direction.Z));
                            result.Add(new TypedValue((int)LispDataType.ListEnd));// End Vector List
                            result.Add(new TypedValue((int)LispDataType.ListEnd));// End Wrap Values
                            result.Add(new TypedValue((int)LispDataType.ListEnd));// Connector Index End
                        }
                        result.Add(new TypedValue((int)LispDataType.ListEnd));// End PORTS ASSOC group
                    }
                    #endregion
                }
                catch
                {
                    tr.Dispose();
                }
                result.Add(new TypedValue((int)LispDataType.ListEnd));
            }
            if (PropNames.Count < 1 || result.AsArray().Length < 3)
            {
                result = new ResultBuffer();
                result.Add(new TypedValue((int)LispDataType.Nil));
            }
            return result;
        } // End GetP3DValues



        [LispFunction("SetPlantValues")]
        public static ResultBuffer SetP3DValues(ResultBuffer args)
        {
            ResultBuffer result = new ResultBuffer();
            TypedValue[] tvList;
            ObjectId EntID;
            string PropName;
            string PropValue;
            try
            {
                tvList = args.AsArray();
                EntID = (ObjectId)tvList[0].Value;
                PropName = (string)tvList[1].Value;
                PropValue = (string)tvList[2].Value;
            }
            catch
            {
                result.Add(new TypedValue((int)LispDataType.Nil));
                return result;
            }
            
            
            Autodesk.AutoCAD.ApplicationServices.Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor.Document;
            PipingProject pipe = (PipingProject)PlantApplication.CurrentProject.ProjectParts["Piping"];
            DataLinksManager dlm = pipe.DataLinksManager;
            TransactionManager tm = doc.Database.TransactionManager;
            PnPDatabase pnpdb = dlm.GetPnPDatabase();
            int PnpRowIndex;
            List<KeyValuePair<string, string>> properties;
            bool WasTrue = false;
            using (Transaction tr = tm.StartTransaction())
            {
                try
                {
                    Part pPart = (Part)tr.GetObject(EntID, OpenMode.ForWrite);
                    PnpRowIndex = dlm.FindAcPpRowId(EntID);
                    PnPRow row = pnpdb.GetRow(PnpRowIndex);
                    properties = dlm.GetAllProperties(PnpRowIndex, true);                    
                    StringCollection Names = new StringCollection();
                    StringCollection Values = new StringCollection();
                    foreach (KeyValuePair<string, string> x in properties)
                    {
                        Names.Add(x.Key);
                        if (x.Key.ToUpper().Trim() == PropName.ToUpper().Trim())
                        {
                            Values.Add(PropValue); WasTrue = true;
                        }
                        else
                        {
                            Values.Add(x.Value);
                        }
                    }
                    dlm.SetProperties(EntID, Names, Values);
                    tr.Commit();
                }
                catch
                {
                    tr.Dispose();
                }
            }                        

            if(WasTrue == true)
            {
                result.Add(new TypedValue((int)LispDataType.T_atom, true));
            }
            else
            {
                result.Add(new TypedValue((int)LispDataType.Nil, null));
            }
            return result;
        } //  End SetP3DValues

    } // End HOB_Functions


} // End P3Dplugin Namespace
