﻿using System.Collections.Generic;
using Autodesk.Navisworks.Api.Plugins;
using System;
using System.Reflection;



namespace HOBNavisCommandDoc
{
    

    static class HOB_Global_Vars
    {       
        public static List<string> cmdList = new List<string>();
        private static System.Collections.ObjectModel.ObservableCollection<string> _itemList = new System.Collections.ObjectModel.ObservableCollection<string>();
        public static System.Collections.ObjectModel.ObservableCollection<string> cmdDisplay
        {
            get { return _itemList; }
            set { _itemList = value; }
        }
    }
    
    
    [DockPanePluginAttribute(400, 600, AutoScroll = true, FixedSize = false, MinimumHeight = 100, MinimumWidth = 100),
        PluginAttribute("NavisworksNetAddinCS1.DockPanePlugin1", "NNAW", DisplayName = "HOB Command Execute Example", ExtendedToolTip = "", Options = PluginOptions.None, SupportsIsSelfEnabled = false, ToolTip = "")]
    public class DockPane1 : DockPanePlugin
    {
    DocInterface HOBdlg = new DocInterface();


        public override System.Windows.Forms.Control CreateControlPane()
        {
            System.Windows.Forms.Integration.ElementHost host = new System.Windows.Forms.Integration.ElementHost();
            host.AutoSize = true;
            host.Child = HOBdlg;
            host.CreateControl();
            return host;            
        }

        public override void DestroyControlPane(System.Windows.Forms.Control pane)
        {
            System.Windows.Forms.UserControl control = pane as System.Windows.Forms.UserControl;
            if (control != null)
            {
                control.Dispose();
            }
        }

        public override void OnActivePaneChanged(bool isActive)
        {
            base.OnActivePaneChanged(isActive);
        }

        public override void OnVisibleChanged()
        {
            base.OnVisibleChanged();
        }
        
        protected override void OnLoaded()
        {
            HOB_Global_Vars.cmdList.Clear();
            System.Windows.Forms.IWin32Window win;
            win = Autodesk.Navisworks.Api.Application.Gui.MainWindow;
            string NavisXML = (string)win.GetType().GetProperty("CommandFile").GetValue(win);
            string[] lines = System.IO.File.ReadAllLines(NavisXML);            
            char[] trs = { '>', '<', ' ', '\"', '/' };
            string ccd = "";
            string str = "";
            foreach (string s in lines)
            {
                str = s.Replace(" ", "");
                ccd = "";
                if (str.ToUpper().Contains("COMMAND ID=") == true)
                {
                    ccd = str.Substring(str.ToUpper().IndexOf("COMMAND ID=") + 10).Trim(trs);
                }
                else if (str.ToUpper().Contains("COMMANDID=") == true)
                {
                    ccd = str.Substring(str.ToUpper().IndexOf("COMMANDID=") + 10).Trim(trs);
                }
                if (ccd != "" && HOB_Global_Vars.cmdList.Contains(ccd) == false) { HOB_Global_Vars.cmdList.Add(ccd); }
            }
            HOB_Global_Vars.cmdDisplay.Clear();
            foreach (string x in HOB_Global_Vars.cmdList)
            {
                HOB_Global_Vars.cmdDisplay.Add(x);
            }
            HOBdlg.lstCommands.ItemsSource = HOB_Global_Vars.cmdDisplay;            
            base.OnLoaded();
        }        
    }
}
