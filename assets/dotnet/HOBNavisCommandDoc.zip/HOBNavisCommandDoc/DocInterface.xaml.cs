﻿using System.Windows;
using System.Windows.Controls;

namespace HOBNavisCommandDoc
{
    /// <summary>
    /// Interaction logic for EditSetting.xaml
    /// </summary>
    public partial class DocInterface : UserControl
    {
        public DocInterface()
        {
            InitializeComponent();
        }

        private void btnExecute_Click(object sender, RoutedEventArgs e)
        {
            ComboBoxItem si = cmbContext.SelectedItem as ComboBoxItem;            
            int ti = System.Convert.ToInt16(si.Tag.ToString());
            Autodesk.Navisworks.Api.Interop.LcUCIPExecutionContext av = (Autodesk.Navisworks.Api.Interop.LcUCIPExecutionContext)ti;            
            try
            {
                Autodesk.Navisworks.Api.Interop.LcRmFrameworkInterface.ExecuteCommand(tbxCommand.Text.Trim(), av);
            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("This tool does not appear to be supported");
            }
        }

        private void lstCommands_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lstCommands.SelectedValue != null && lstCommands.SelectedValue.ToString().Length >= 1)
            {
                tbxCommand.Text = lstCommands.SelectedValue.ToString();
            }
        }

        private void tbxFilter_TextChanged(object sender, TextChangedEventArgs e)
        {
            System.Collections.ObjectModel.ObservableCollection<string> tmp = new System.Collections.ObjectModel.ObservableCollection<string>();
            HOB_Global_Vars.cmdDisplay.Clear();
            if (tbxFilter.Text.ToUpper().Trim() != "")
            {
                foreach (string x in HOB_Global_Vars.cmdList)
                {
                    if (x.ToUpper().Contains(tbxFilter.Text.ToUpper().Trim()))
                    {
                        HOB_Global_Vars.cmdDisplay.Add(x);
                    }
                }
            }
            else
            {
                foreach (string x in HOB_Global_Vars.cmdList)
                {
                    HOB_Global_Vars.cmdDisplay.Add(x);
                }
            }
            

        }
    }
}
