To load this plugin, you need to put it somewhere other than on a network drive.
If you think you will be using it on a regular basis, then I would suggest you go ahead and add it to trusted paths.

From Plant 3D type Netload and target this DLL.
This will load the GetPlantValues & SetPlantValues lisp functions.

Visit house of houseofbim.com and find "Project Alyobabetous" for some more in depth usage information.